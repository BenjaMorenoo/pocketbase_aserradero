/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1736455494")

  // update field
  collection.fields.addAt(6, new Field({
    "hidden": false,
    "id": "select240467767",
    "maxSelect": 1,
    "name": "rol",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "select",
    "values": [
      "pedidos",
      "produccion",
      "admin"
    ]
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1736455494")

  // update field
  collection.fields.addAt(6, new Field({
    "hidden": false,
    "id": "select240467767",
    "maxSelect": 1,
    "name": "rol",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "select",
    "values": [
      "pedidos",
      "produccion"
    ]
  }))

  return app.save(collection)
})
